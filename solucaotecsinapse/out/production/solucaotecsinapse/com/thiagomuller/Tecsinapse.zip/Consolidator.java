package com.thiagomuller;

import java.util.*;

public class Consolidator {
    private CsvOrderParser orderParser;
    private List<Order> listOfValidatedOrders;
    private Map<String, List<Double>> consolidatedItems;


    public Consolidator(String csvFile, int desiredMonth){
        this.orderParser = new CsvOrderParser(csvFile, desiredMonth);
        this.listOfValidatedOrders = orderParser.mapCSVFileToOrderList();
        this.consolidatedItems = new HashMap<>();
    }


    public void aggregateAndSumOrdersForItem(){
        listOfValidatedOrders.forEach(order -> {
            String item = order.getItem();
            double quantity = order.getQuantity();
            double price = order.getPrice();
            addOrUpdateToConsolidatedItems(item, quantity, price);
        });
    }

    public void addOrUpdateToConsolidatedItems(String currentItem, double currentQty, double currentPrice){
        if(!consolidatedItems.containsKey(currentItem)){
            consolidatedItems.put(currentItem, Arrays.asList(currentQty, currentPrice));
        } else{
            updateAndReplaceToConsolidatedItems(currentItem, currentQty, currentPrice);
        }
    }

    public void updateAndReplaceToConsolidatedItems(String currentItem, double currentQty, double currentPrice){
        double updatedQty = consolidatedItems.get(currentItem).get(0) + currentQty;
        double updatedPrice = consolidatedItems.get(currentItem).get(1) + currentPrice;
        consolidatedItems.replace(currentItem, Arrays.asList(updatedQty, updatedPrice));
    }

    public Map<String, List<Double>> getConsolidatedItems(){
        aggregateAndSumOrdersForItem();
        return consolidatedItems;
    }

}
