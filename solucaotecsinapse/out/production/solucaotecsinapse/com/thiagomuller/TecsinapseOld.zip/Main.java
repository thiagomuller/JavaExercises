package com.thiagomuller;

import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        CSVHandler csvHandler = new CSVHandler("/home/thiago/Documents/JavaProjectsAndExercises/JavaExercises/solucaotecsinapse/recrutamento.csv", 12);
        Map<String, List<Double>> result = csvHandler.mapCsvFile();
        System.out.println(result);
    }
}
