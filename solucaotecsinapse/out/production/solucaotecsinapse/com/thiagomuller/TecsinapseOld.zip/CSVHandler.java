package com.thiagomuller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class CSVHandler {
    private int desiredMonth;
    private GreatestQtysAndPrices greatestQtysAndPrices;
    private String csvFile;
    private String line;
    private BufferedReader bufferedReader;

    public CSVHandler(String csvFile, int desiredMonth) {
        this.csvFile = csvFile;
        this.desiredMonth = desiredMonth;
        this.greatestQtysAndPrices = new GreatestQtysAndPrices();
        this.line = "";
        this.bufferedReader = null;
    }

    public Map<String, List<Double>> mapCsvFile(){
        try{
            bufferedReader = new BufferedReader(new FileReader(csvFile));
            int counter = 0;
            while((line = bufferedReader.readLine()) != null){
                List<String>currentLineInFile = Arrays.asList(line.split(";"));
                if(compareMonth(counter, currentLineInFile)){
                    String currentItem = currentLineInFile.get(0);
                    double currentQty = Double.valueOf(currentLineInFile.get(1));
                    double currentPrice = Double.valueOf(currentLineInFile.get(3).replace(',','.'));
                    greatestQtysAndPrices.sumQtyAndPrice(currentItem, currentQty, currentPrice);
                }
                counter ++;
            }
            
            return greatestQtysAndPrices.getTheGreatestItem();

        } catch(FileNotFoundException file){
            System.out.println("File not found, please verify if the file is in the specified address, of if the address is correct!");
            file.printStackTrace();
        } catch(IOException e){
            e.printStackTrace();
        }
        return null;
    }

    public boolean compareMonth(int counter, List<String> currentLineInFile){
        if(counter > 0){
            int month = Integer.valueOf(currentLineInFile.get(2).split("/")[1]);
            if(month == desiredMonth){
                return true;
            }
        }
        return false;
    }
}
