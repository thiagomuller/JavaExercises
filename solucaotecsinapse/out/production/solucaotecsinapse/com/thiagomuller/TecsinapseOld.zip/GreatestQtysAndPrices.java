package com.thiagomuller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GreatestQtysAndPrices {
    private Map<String, List<Double>> greatestQtysAndPrices;
    private String previousKey = "";

    public GreatestQtysAndPrices() {
        this.greatestQtysAndPrices = new HashMap<>();
    }


    public void sumQtyAndPrice(String currentItem, double currentQty, double currentPrice){
        if(!greatestQtysAndPrices.containsKey(currentItem)){
            greatestQtysAndPrices.put(currentItem, Arrays.asList(currentQty, currentPrice));
        } else{
            updateAndReplace(currentItem, currentQty, currentPrice);
        }
    }

    public void updateAndReplace(String currentItem, double currentQty, double currentPrice){
        double updatedQty = greatestQtysAndPrices.get(currentItem).get(0) + currentQty;
        double updatedPrice = greatestQtysAndPrices.get(currentItem).get(1) + currentPrice;
        greatestQtysAndPrices.replace(currentItem, Arrays.asList(updatedQty, updatedPrice));
    }

    public Map<String, List<Double>> getTheGreatestItem(){
        Map<String, List<Double>> finalResult = new HashMap<>();
        for(String key : greatestQtysAndPrices.keySet()){
            isFinalResultEmpty(finalResult, key);
            double previousQty = finalResult.get(previousKey).get(0);
            double previousPrice = finalResult.get(previousKey).get(1);
            isCurrentQtyGreaterThanPreviousQty(finalResult, key, previousQty);
        }

        return finalResult;
    }

    public void isFinalResultEmpty(Map<String, List<Double>> finalResult, String key){
        if(finalResult.isEmpty()){
            finalResult.put(key , greatestQtysAndPrices.get(key));
            previousKey = key;

        }
    }

    public void isCurrentQtyGreaterThanPreviousQty(Map<String, List<Double>> finalResult, String key, double previousQty){
        if(greatestQtysAndPrices.get(key).get(0) > previousQty){
            finalResult.remove(previousKey);
            finalResult.put(key, greatestQtysAndPrices.get(key));
            previousKey = key;
        }
    }
}
